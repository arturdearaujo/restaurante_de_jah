#include "table.h"

Table::Table()
{

}
