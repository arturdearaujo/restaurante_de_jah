#include "client.h"

Client::Client()
{

}
QString setUsername()
{
    return 0;
}
