#include "restaurant.h"

Restaurant::Restaurant()
{

}
