#include "sharedbill.h"

SharedBill::SharedBill()
{

}
