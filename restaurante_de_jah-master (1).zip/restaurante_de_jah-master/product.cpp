#include "product.h"

Product::Product()
{

}

