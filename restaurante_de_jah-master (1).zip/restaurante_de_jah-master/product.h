#ifndef PRODUCT_H
#define PRODUCT_H
#include <iostream>
#include <QString>

class Product
{
public:
    Product();
    double price;
    QString name;
};

#endif // PRODUCT_H
