#include "billitem.h"
#include "product.h"

BillItem::BillItem()
{

}
