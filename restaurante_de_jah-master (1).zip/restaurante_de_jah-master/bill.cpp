#include "bill.h"

Bill::Bill()
{

}
